from django.shortcuts import render,get_object_or_404,redirect
from .models import *
from django.contrib.auth import logout,login,authenticate
from django.contrib.auth.forms import UserCreationForm
from django.core.mail import send_mail,BadHeaderError
from django.http import HttpResponse,HttpResponseRedirect
from .forms import *
from django.db.models import Q
from mysite.settings import EMAIL_HOST_USER
from django.core.mail import send_mail



# Create your views here.

def Movies_List(request):
    Latest_Movies = Movie.objects.filter(Movie_Year__startswith=2019)[:6]
    Kannada_Movies = Movie.objects.filter(Movie_Language__startswith="Kannada")[:6]
    Telugu_Movies = Movie.objects.filter(Movie_Language__startswith="Telugu")[:6]
    rate = Movie.objects.filter(Movie_Rating__startswith=8).order_by('Movie_Rating').reverse()[:6]
    return render(request,'Movie/movies_list.html',{'Latest':Latest_Movies,'Kannada':Kannada_Movies,'Telugu':Telugu_Movies,'Rate':rate})


def Movie_Details(request,pk):
    movie = get_object_or_404(Movie,Movie_id=pk)
    try:
        rent = Rent.objects.get(movie_id=pk)
    except Rent.DoesNotExist:
        rent = Rent.objects.filter(movie_id=pk)
    return render(request,'Movie/movie_details.html',{'movie':movie,'rent':rent})


def Home(request):
    return render(request,'Movie/page.html')


def All_Movies(request):
    movies = Movie.objects.all()
    return render(request,'Movie/all_movies.html',{'movies':movies})


def Logout_View(request):
    logout(request)
    return redirect('home')


def User_View(request):
    rent = Rent.objects.filter(user=request.user)
    contact = Contact.objects.filter(user=request.user)
    return render(request,'Movie/user_view.html',{'contact':contact,'rent':rent})


def Sign_Up(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password1')
            user = authenticate(username=username,password=password)
            login(request,user)
            return redirect('home')

    else:
        form = UserCreationForm()
    return render(request,'registration/signup.html',{'form':form})



def SearchMovies(request):
        if request.method == 'GET':
            query = request.GET.get('query')
            print(query)
            if query:
                results = Movie.objects.filter(
                Q(Movie_Name__icontains=query) | Q(Movie_Year__icontains=query) | Q(Movie_Language__icontains=query) | Q(Movie_Genre__icontains=query)).distinct()
                return render(request,'Movie/search.html',{'results':results})
            else:
                return render(request,'Movie/search.html',)



def Mains(request):
    return render(request,'Movie/main.html')



def Email_View(request):
    if request.method == 'GET':
        form = ContactForm()
    else:
        form = ContactForm(request.POST)
        if form.is_valid():
            contact = form.save(commit=False)
            contact.user = request.user
            contact.save()
            Name = form.cleaned_data['Name']
            From_Email = form.cleaned_data['From_Email']
            Message = form.cleaned_data['Message']
            subject = 'Greetings from Movie Magnet'
            message = 'Hope you are enjoying our website : Our support team will get back to you in some time '
            try:
                send_mail(subject,message, EMAIL_HOST_USER, [From_Email], fail_silently = False)
            except BadHeaderError:
                return HttpResponse('Invalid header found')
            return redirect('success')
    return render(request,"Movie/contact.html",{'form':form})

def Success_View(request):
    return render(request,'Movie/success.html')


def Rented(request):
    rent =Rent.objects.filter(user=request.user).distinct()
    return render(request,'Movie/rented.html',{'rent':rent})


def Rented_Details(request,pk):
    rented_detail =  get_object_or_404(Movie,Movie_id=pk)
    return render(request,'Movie/rented_details.html',{'rented_detail':rented_detail})

def Watch(request):
    return render(request,'Movie/watch.html',)

def rent(request,pk):
    movie = get_object_or_404(Movie,Movie_id=pk)

    if request.method == 'GET':
        form = RentedForm()
    else:
        form = RentedForm(request.POST)
        if form.is_valid():
            Pk = pk
            rents = form.save(commit=False)
            rent = form.save(commit=False)
            rents.user = request.user
            rent.movie_id = Movie.objects.get(pk=pk)
            rents.save()
            return redirect('purchase',{'pk':Pk})

    return render(request,'Movie/rented_form.html',{'form':form,'movie':movie,})

def Purchase(request,pk):

    if request.method == 'GET':
        form = PurchaseForm()
    else:
        form = PurchaseForm(request.POST)
        if form.is_valid():
            purchase = form.save(commit=False)
            rent = form.save(commit=False)
            purchase.F_Name =form.cleaned_data['F_Name']
            purchase.L_Name =form.cleaned_data['L_Name']
            purchase.Phone =form.cleaned_data['Phone']
            purchase.Payment =form.cleaned_data['Payment']
            purchase.save()
            payment = purchase.Payment
            return redirect('rentedsuccess',{"payment":payment})
    return render(request,'Movie/Purchase.html',{'form':form,})


def RentedSuccessView(request,str):
    pay = str[13:-2]
    return render(request,'Movie/rented_success.html',{'str':pay})
